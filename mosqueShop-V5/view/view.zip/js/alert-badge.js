
$('.alert').alert();

$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip();
});


