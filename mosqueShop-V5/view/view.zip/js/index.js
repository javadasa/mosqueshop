// let scrollTopBtn = document.querySelector('#scroll-top-btn');

// window.addEventListener('scroll', scrollTop());

// const scrollTop = () => {
//     if (document.body.scrollTop > 500) {
//         scrollTopBtn.style.display = "block !important";
//     } else {
//         scrollTopBtn.style.display = "none !important";
//     }
// }