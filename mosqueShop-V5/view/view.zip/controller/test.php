<?php
include('../controller/index.php');
include('../controller/newsDetail.php');

print_r($newImage);